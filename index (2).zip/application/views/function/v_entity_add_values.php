<div class="page-header">
    <h1 class="page-title">ENTITY VALUES</h1>
    <br/>
    <ol class="breadcrumb breadcrumb-arrow">
        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
        <li class="breadcrumb-item"><a href="javascript:void(0)">Entity</a></li>
        <li class="breadcrumb-item">Add Values</li>
    </ol>
</div>
<br/>
<div class="page-body col-lg-12">
    <div class="row row-lg">
        <div class="col-xl-12">
            <!-- Example Tabs Left -->
            <div class="example-wrap">
                <div class="nav-tabs-vertical" data-plugin="tabs">
                    <ul class="nav nav-tabs mr-25" role="tablist">
                        <li class="nav-item" role="presentation"><a class="nav-link active" data-toggle="tab" href="#primaryData" aria-controls="primaryData" role="tab">Primary Data</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#current" aria-controls="primaryData" role="tab">Current Values</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" data-toggle="tab" href="#values" aria-controls="primaryData" role="tab">Add Values</a></li>

                    </ul>
                    <form action = "<?php echo base_url();?>function/entity/submit_values" method = "post" enctype = "multipart/form-data">    
                        <div class="tab-content">
                            <div class="tab-pane active" id="primaryData" role="tabpanel">
                                <input type = "hidden" name = "id_submit_entity" value = "<?php echo $entity[0]["id_submit_entity"];?>">
                                <table class = "table table-striped table-bordered table-hover">
                                    <tr>
                                        <th style = "width:30%">Entity Name</th>
                                        <td><?php echo $entity[0]["entity_name"];?></td>
                                    </tr>
                                    <tr>
                                        <th style = "width:30%">Entity Description</th>
                                        <td><?php echo $entity[0]["entity_desc"];?></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="tab-pane" id="current" role="tabpanel">
                                <br/><br/>
                                <table class = "table table-stripped table-bordered table-hover" style = "width:100%" data-plugin = "dataTable">
                                    <thead>
                                        <td style = "width:5%">#</td>
                                        <td style = "width:5%">UPDATE</td>
                                        <td style = "width:5%">DELETE</td>
                                        <td>Entity Example</td>
                                        <td style = "width:5%">How do you describe it?</td>
                                        <td style = "width:5%">Action</td>
                                    </thead>
                                    <?php //ambil yang entity dalam kategori informasi tersebut ?>
                                    <tbody>
                                        <?php for($b = 0; $b<count($entity_value); $b++):?>
                                        <tr>
                                            <td><?php echo $b+1;?></td>
                                            <td>
                                                <div class = "checkbox-custom checkbox-primary">
                                                    <input type = "checkbox">
                                                    <label></label>
                                                </div>
                                            </td>
                                            <td>
                                                <div class = "checkbox-custom checkbox-primary">
                                                    <input type = "checkbox">
                                                    <label></label>
                                                </div>
                                            </td>
                                            <td><?php echo $entity_value[$b]["entity_value"];?></td>
                                            <td>
                                                <button type = "button" class = "btn btn-primary btn-sm col-lg-12">EXPRESSION</button>
                                            </td>
                                            <td></td>
                                        </tr>

                                        <?php endfor;?>
                                    </tbody>
                                </table>
                                <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
                            </div>
                            <div class="tab-pane" id="values" role="tabpanel">
                                <div class = "form-group">
                                    <h5>Entity Example</h5>
                                    <input class="form-control col-lg-12" name="tags" id = "list_tabel" data-plugin="tagsinput" value=""/>
                                </div>
                                <button onclick = "loadExample()" type = "button" class = "btn btn-primary btn-sm">LOAD EXAMPLE</button>
                                
                                <br/><br/>
                                <table class = "table table-stripped table-bordered table-hover">
                                    <thead>
                                        <td style = "width:5%">#</td>
                                        <td>Entity Example</td>
                                        <td>How do you describe it?</td>
                                        <td style = "width:5%">Action</td>
                                    </thead>
                                    <?php //ambil yang entity dalam kategori informasi tersebut ?>
                                    <tbody id = "tableEntity">
                                        
                                    </tbody>
                                </table>
                                <button type = "submit" class = "btn btn-primary btn-sm">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class = "form-group">
                <a href = "<?php echo base_url();?>function/entity" class = "btn btn-outline btn-primary btn-sm">BACK</a>
            </div>
            <!-- End Example Tabs Left -->
        </div>
    </div>
</div>
<script src="<?php echo base_url();?>assets/global/vendor/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/jquery-selective/jquery-selective.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/bootstrap-markdown/bootstrap-markdown.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/bootbox/bootbox.js"></script>


<script src="<?php echo base_url();?>assets/global/js/Plugin/bootstrap-select.js"></script>
<script src="<?php echo base_url();?>assets/global/js/Plugin/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url();?>assets/global/js/Plugin/bootbox.js"></script>
<script src="<?php echo base_url();?>assets/js/BaseApp.js"></script>
<script src="<?php echo base_url();?>assets/js/App/Taskboard.js"></script>

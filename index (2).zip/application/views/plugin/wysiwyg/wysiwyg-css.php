
<link rel="stylesheet" href="<?php echo base_url();?>global/vendor/summernote/summernote.css">
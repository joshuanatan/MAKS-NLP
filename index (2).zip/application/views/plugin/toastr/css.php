<link rel="stylesheet" href="<?php echo base_url();?>global/vendor/toastr/toastr.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/examples/css/advanced/toastr.css">
        
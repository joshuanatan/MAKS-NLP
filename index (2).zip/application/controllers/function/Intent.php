<?php
class Intent extends CI_Controller{
    private $id_wit_acc;
    public function __construct(){
        parent::__construct();
        $this->load->library("wit");
        $where = array(
            "status_aktif_wit_ai_acc" => 1
        );
        $this->id_wit_acc = get1Value("tbl_wit_ai_acc","id_submit_wit_ai_acc",$where);
    }
    public function check_exists_intent(){
        $this->check_session();
        $where = array(
            "entity_name" => "intent",
            "status_aktif_entity" => 1,
            "id_wit_ai_acc" => $this->id_wit_acc
        );
        $field = array(
            "id_submit_entity"
        );
        $result = selectRow("tbl_entity",$where,$field);
        if($result->num_rows() == 0){ /*not exists*/
            $data = array(
                "entity_name" => "intent",
                "entity_desc" => "manage intention of every spoken sentence",
                "tgl_entity_add" => date("Y-m-d H:i:S"),
                "id_user_entity_add" => $this->session->id_user
            );
            $id_submit_entity = insertRow("tbl_entity",$data);
            $id = "intent";
            $doc = "manage intention of every spoken sentence";
            $response = $this->wit->post_entities($id, $doc);
            if ($response["err"]) {
                $msg = $response["err"];
                $this->session->set_flashdata("status_wit","error"); 
                $this->session->set_flashdata("msg_wit",$msg);
            } 
            else {
                $respond = json_decode($response["response"],true);
                if(!array_key_exists("error",$respond)){
                    $msg = "New entity called 'intent' is added to Wit.ai".". ";
                    $this->session->set_flashdata("status_wit","error"); 
                    $this->session->set_flashdata("msg_wit",$msg);
                    $where = array(
                        "id_submit_entity" => $id_submit_entity   
                    );
                    $data = array(
                        "entity_wit_id" => $respond["id"],
                        "status_aktif_entity" => 1
                    );
                    updateRow("tbl_entity",$data,$where);
                    
                    $msg = "Welcome to Intention management function".". ";
                    $this->session->set_flashdata("status_entity","error"); 
                    $this->session->set_flashdata("msg_entity",$msg);
                }
            }
        }
        else{
            $result_array = $result->result_array();
            $id_submit_entity = $result_array[0]["id_submit_entity"];
        }
        return $id_submit_entity;
    }
    public function index(){
        $this->check_session();
        $id_submit_entity = $this->check_exists_intent();
        $where = array(
            "id_entity" => $id_submit_entity,
            "status_aktif_entity_value <" => 2,
        );
        $field = array(
            "id_submit_entity_value","entity_value","status_aktif_entity_value","tgl_entity_value_add","tgl_entity_value_edit","tgl_entity_value_delete"
        );
        $result = selectRow("tbl_entity_value",$where,$field);
        $data["intent"] = $result->result_array();
        $data["id_submit_entity"] = $id_submit_entity;
        
        $this->page_generator->req();
        $this->load->view("plugin/datatable/datatable-css");
        $this->page_generator->head_close();
        $this->page_generator->navbar();
        $this->page_generator->content_open();
        $this->load->view("function/v_intent",$data);
        $this->page_generator->close();
        $this->load->view("plugin/datatable/datatable-js");
        $this->load->view("function/v_intent_js");
    }
    public function recycle_bin(){
        $this->check_session();
        $id_submit_entity = $this->check_exists_intent();
        $where = array(
            "id_entity" => $id_submit_entity,
            "status_aktif_entity_value" => 2
        );
        $field = array(
            "id_submit_entity_value","entity_value","status_aktif_entity_value","tgl_entity_value_add","tgl_entity_value_edit","tgl_entity_value_delete"
        );
        $result = selectRow("tbl_entity_value",$where,$field);
        $data["intent"] = $result->result_array();
        $data["id_submit_entity"] = $id_submit_entity;
        
        $this->page_generator->req();
        $this->load->view("plugin/datatable/datatable-css");
        $this->page_generator->head_close();
        $this->page_generator->navbar();
        $this->page_generator->content_open();
        $this->load->view("function/v_intent_recycle_bin",$data);
        $this->page_generator->close();
        $this->load->view("plugin/datatable/datatable-js");
        $this->load->view("function/v_intent_js");
    }
    public function insert_entity_value(){
        $this->check_session();
        $checks = $this->input->post("add_check");
        if($checks != ""){
            foreach($checks as $a){
                $config = array(
                    array(
                        "field" => "id_entity",
                        "label" => "ID Intent",
                        "rules" => "required"
                    ),
                    array(
                        "field" => "entity_value".$a,
                        "label" => "Intention",
                        "rules" => "required"
                    )
                );
                $this->form_validation->set_rules($config);
                $value = $this->input->post("entity_value".$a);
                if($this->form_validation->run()){
                    $data = array(
                        "id_entity" => $this->input->post("id_entity"),
                        "entity_value" => $value,
                        "tgl_entity_value_add" => date("Y-m-d H:i:s"),
                        "status_aktif_entity_value" => 0,
                        "id_user_entity_value_add" => $this->session->id_user
                    );
                    $id_submit_entity_value = insertRow("tbl_entity_value",$data);
                    $response = $this->wit->post_entities_value("intent", $value);
                    if ($response["err"]) {
                        $msg = $response["err"];
                        $this->session->set_flashdata("status_wit","error");
                        $this->session->set_flashdata("msg_wit",$msg);
                    } 
                    else {
                        $respond = json_decode($response["response"],true);
                        if(!array_key_exists("error",$respond)){
                            $msg = "Intent is successfully added to Wit.ai";
                            $this->session->set_flashdata("status_wit","success");
                            $this->session->set_flashdata("msg_wit",$msg);

                            $where = array(
                                "id_submit_entity_value" => $id_submit_entity_value   
                            );
                            $data = array(
                                "status_aktif_entity_value" => 1
                            );
                            updateRow("tbl_entity_value",$data,$where);
                            $msg = "Intent is successfully added to the system";
                            $this->session->set_flashdata("status_entity","success");
                            $this->session->set_flashdata("msg_entity",$msg);
                        }
                        else{
                            $msg = $respond["error"];
                            $this->session->set_flashdata("status_wit","error");
                            $this->session->set_flashdata("msg_wit",$msg);
                        }
                    }
                }
            }
        }
        $this->redirect();

    }
    public function update_entity_value(){
        $this->check_session();
        $config = array(
            array(
                "field" => "id_submit_entity_value",
                "label" => "ID Intent",
                "rules" => "required"
            ),
            array(
                "field" => "entity_value",
                "label" => "Intent",
                "rules" => "required"
            )
        );
        $this->form_validation->set_rules($config);
        if($this->form_validation->run()){
            $entity_value = get1Value("tbl_entity_value","entity_value",array("id_submit_entity_value" => $this->input->post("id_submit_entity_value")));
            $respond = $this->wit->delete_entities_value("intent",$entity_value);

            $entity_value = $this->input->post("entity_value");

            $msg = "";
            if($respond){
                if($respond["err"]){
                    $msg .= $respond["err"].". ";
                    $this->session->set_flashdata("status_wit","error");
                    $this->session->set_flashdata("msg_wit",$msg);
                }
                else{
                    $msg .= "Current intent is removed from Wit.ai".". ";
                    $this->session->set_flashdata("status_wit","success");
                    $this->session->set_flashdata("msg_wit",$msg);
                }
            }
            $respond = $this->wit->post_entities_value("intent",$entity_value);
            if($respond){
                if($respond["err"]){ 
                    $msg .= $respond["err"].". ";
                    $this->session->set_flashdata("status_wit","error");
                    $this->session->set_flashdata("msg_wit",$msg);

                }
                else{
                    $msg .= "New intent is added to Wit.ai".". ";
                    $this->session->set_flashdata("status_wit","success");
                    $this->session->set_flashdata("msg_wit",$msg);
                    
                    $where = array(
                        "id_submit_entity_value" => $this->input->post("id_submit_entity_value")
                    );
                    $data = array(
                        "entity_value" => $this->input->post("entity_value"),
                        "tgl_entity_value_edit" => date("Y-m-d H:i:s"),
                        "id_user_entity_value_edit" => $this->session->id_user
                    );
                    updateRow("tbl_entity_value",$data,$where);

                    $msg .= "New intent is added to database".". ";
                    $this->session->set_flashdata("status_entity","success");
                    $this->session->set_flashdata("msg_entity",$msg);
                }
            }
            $this->redirect();
        }
        else{
            $this->page_generator->req();
            $this->page_generator->head_close();
            $this->page_generator->content_open();
            $this->load->view("function/v_intent_reupdate");
            $this->page_generator->close();
        }
    }
    public function remove_entity_value($id_submit_entity_value){
        $this->check_session();
        $where = array(
            "id_submit_entity_value" => $id_submit_entity_value
        );
        $field = array(
            "entity_value"
        );
        $result = selectRow("tbl_entity_value",$where,$field);
        $result_array = $result->result_array();
        $entity_value = $result_array[0]["entity_value"];
        $respond = $this->wit->delete_entities_value("intent",$entity_value);
        if($respond){
            if($respond["err"]){
                $msg = $respond["err"];
                $this->session->set_flashdata("status_wit","error");
                $this->session->set_flashdata("msg_wit",$msg);
            }
            else{
                $respond = json_decode($respond["response"],true);
                if(!array_key_exists("error",$respond)){
                    
                    $msg = "Intent is successfully removed from Wit.ai";
                    $this->session->set_flashdata("status_wit","success");
                    $this->session->set_flashdata("msg_wit",$msg);
                    $where = array(
                        "id_submit_entity_value" => $id_submit_entity_value
                    );
                    
                    $data = array(
                        "status_aktif_entity_value" => 2,
                        "tgl_entity_value_delete" => date("Y-m-d H:i:s"),
                        "id_user_entity_value_delete" => $this->session->id_user
                    );
                    updateRow("tbl_entity_value",$data,$where);
                    $msg = "Intent is successfully removed from database";
                    $this->session->set_flashdata("status_entity","success");
                    $this->session->set_flashdata("msg_entity",$msg);
                }
                else{
                    $msg = $respond["error"];
                    $this->session->set_flashdata("status_wit","error");
                    $this->session->set_flashdata("msg_wit",$msg);
                }
            }
            $this->redirect();
        }
    }
    public function delete_entity_value($id_submit_entity_value){
        $this->check_session();
        $where = array(
            "id_submit_entity_value" => $id_submit_entity_value
        );
        $field = array(
            "entity_value"
        );
        $result = selectRow("tbl_entity_value",$where,$field);
        $result_array = $result->result_array();
        $entity_value = $result_array[0]["entity_value"];
        $respond = $this->wit->delete_entities_value("intent",$entity_value);
        if($respond){
            if($respond["err"]){
                $msg = $respond["err"];
                $this->session->set_flashdata("status_wit","error");
                $this->session->set_flashdata("msg_wit",$msg);
            }
            else{
                $respond = json_decode($respond["response"],true);
                if(!array_key_exists("error",$respond)){
                    
                    $msg = "Intent is successfully removed from Wit.ai";
                    $this->session->set_flashdata("status_wit","success");
                    $this->session->set_flashdata("msg_wit",$msg);
                    $where = array(
                        "id_submit_entity_value" => $id_submit_entity_value
                    );
                    
                    $data = array(
                        "status_aktif_entity_value" => 0,
                        "tgl_entity_value_delete" => date("Y-m-d H:i:s"),
                        "id_user_entity_value_delete" => $this->session->id_user
                    );
                    updateRow("tbl_entity_value",$data,$where);
                    $msg = "Intent is successfully removed from database";
                    $this->session->set_flashdata("status_entity","success");
                    $this->session->set_flashdata("msg_entity",$msg);
                }
                else{
                    $msg = $respond["error"];
                    $this->session->set_flashdata("status_wit","error");
                    $this->session->set_flashdata("msg_wit",$msg);
                }
            }
            $this->redirect();
        }
    }
    public function reupload_entity_value($id_submit_entity_value){
        $this->check_session();
        
        $where = array(
            "id_submit_entity_value" => $id_submit_entity_value
        );
        $field = array(
            "entity_value"
        );
        $result = selectRow("tbl_entity_value",$where,$field);
        $result_array = $result->result_array();
        $entity_value = $result_array[0]["entity_value"];

        $where = array(
            "id_entity_value" => $id_submit_entity_value,
            "status_aktif_entity_value_expression" => 1
        );
        $field = array(
            "entity_value_expression"
        );
        $result = selectRow("tbl_entity_value_expression",$where,$field);
        $result_array = $result->result_array();

        $expression_list = array();
        for($a = 0; $a<count($result_array); $a++){
            $expression_list[$a] = $result_array[$a]["entity_value_expression"];
        }
        $respond = $this->wit->post_entities_value("intent",$entity_value,$expression_list);
        if($respond){
            if($respond["err"]){
                $msg = $respond["err"];
                $this->session->set_flashdata("status_wit","error");
                $this->session->set_flashdata("msg_wit",$msg);
            }
            else{
                $respond = json_decode($respond["response"],true);
                if(!array_key_exists("error",$respond)){
                    $msg = "Intent is successfully added to Wit.ai";
                    $this->session->set_flashdata("status_wit","success");
                    $this->session->set_flashdata("msg_wit",$msg);
                    $where = array(
                        "id_submit_entity_value" => $id_submit_entity_value
                    );
                    $data = array(
                        "status_aktif_entity_value" => 1,
                        "tgl_entity_value_edit" => date("Y-m-d H:i:s")
                    );
                    updateRow("tbl_entity_value",$data,$where);
                    $msg = "Intent is successfully added to database";
                    $this->session->set_flashdata("status_entity","success");
                    $this->session->set_flashdata("msg_entity",$msg);
                }
                else{
                    $msg = $respond["error"];
                    $this->session->set_flashdata("status_wit","error");
                    $this->session->set_flashdata("msg_wit",$msg);
                }
            }
            $this->redirect();
        }
    }
    public function redirect(){
        $this->check_session();
        redirect("function/intent");
    }
    private function check_session(){
		if($this->session->id_user == ""){
			$msg = "Session Expired";	
			$this->session->set_flashdata("status_login","error");
			$this->session->set_flashdata("msg_login",$msg);
			redirect("welcome");
		}
	}
}
?>